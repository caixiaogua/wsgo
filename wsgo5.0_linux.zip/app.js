
let count=0;
let users=[];

function onOpen(ctx){
	count++;
	if(!users.find(x=>x.Id==ctx.Id))users.push(ctx); //将当前用户加入到用户列表
	console.log("open", ctx.Id, count, users.length);
	api.sendTo([ctx], {login:true}); //返回登录信息给当前用户
}

function onMsg(ctx, msg){
	users=users.filter(u=>u&&u.Errs==0); //删除掉线用户
	console.log("msg", msg);
	api.sendTo(users, {msg}); //广播消息给所有用户
}

function onClose(ctx, err){
	console.log("close", ctx.Id);
}