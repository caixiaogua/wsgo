function onOpen(ctx){
	console.log("open", ctx.Id, "conns", ctx.GetAllConns().length)
}

function onMsg(ctx, msg){
	console.log("msg", msg)
	{//操作共享变量代码块
		let db=ctx.DbGet();
		console.log("db",db)
		if(!db.main)db.main=[];
		if(!db.vars)db.vars={};
		let main=[...db.main];
		if(!main.find(x=>x.Id==ctx.Id))db.main=[...main,ctx];
		db.vars.time=new Date();
		ctx.DbDone();
	}//操作共享变量结束
	let conns=ctx.GetAllConns() //获取当前所有连接实例
//	console.log("conns", conns.length, JSON.stringify(conns))
//	conns=conns.filter(function(x){return x.Id!=ctx.Id}) //除自己外其他人
	ctx.SendTo(conns, "Reply:"+msg)
}

function onClose(ctx, err){
	console.log("close")
}