package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/robertkrimen/otto"
	"golang.org/x/net/websocket"
)

var USERS = make(map[*websocket.Conn]Ctx)
var vm = otto.New()

type Ctx struct {
	Conn *websocket.Conn
	Id   string
}

func (this Ctx) GetAllConns() []Ctx {
	ks := make([]Ctx, len(USERS))
	idx := 0
	for _, v := range USERS {
		ks[idx] = v
		idx++
	}
	// fmt.Println(ks)
	return ks
}
func (this Ctx) SendTo(cs []Ctx, msg string) {
	// fmt.Println(cs, msg)
	for _, c := range cs {
		sendToOne(c, msg)
	}
}

func sendToOne(ctx Ctx, msg string) error {
	if err := websocket.Message.Send(ctx.Conn, msg); err != nil {
		fmt.Println(err)
		if strings.Contains(err.Error(), "aborted") {
			vm.Call("onClose", nil, ctx, err)
		}
		return err
	}
	return nil
}

func wsk(ws *websocket.Conn) {
	var err error
	var ctx = Ctx{
		Conn: ws,
		Id:   fmt.Sprint(ws.RemoteAddr().String(), "_", time.Now().UnixNano()),
	}
	USERS[ws] = ctx
	// ws.RemoteAddr().String()
	vm.Call("onOpen", nil, ctx)
	for {
		var reply string

		if err = websocket.Message.Receive(ws, &reply); err != nil {
			fmt.Println(err)
			if strings.Contains(err.Error(), "aborted") || err.Error() == "EOF" {
				vm.Call("onClose", nil, ctx, err)
				delete(USERS, ws)
				break
			}
			continue
		}

		if reply != "" {
			// fmt.Println(ws.RemoteAddr(), reply)
			// fmt.Printf("%+v", ws.Config)
			_, err := vm.Call("onMsg", nil, ctx, reply)
			if err != nil {
				fmt.Println("onMsg.Error", err)
			}
		}
	}
	// vm.Call("onClose", nil, ws)
}

func getFileStr(file string) string {
	data, err := ioutil.ReadFile(file)
	if err != nil || data == nil {
		fmt.Println("File reading error", err)
		return ""
	}
	return string(data)
}

func main() {
	str := getFileStr("index.js")
	_, err := vm.Run(str)
	if err != nil {
		fmt.Println("error", err)
	}
	http.Handle("/", websocket.Handler(wsk))
	port := "8800"
	if len(os.Args) > 1 {
		port = os.Args[1]
	}
	fmt.Println("Server is running at " + port)
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}
