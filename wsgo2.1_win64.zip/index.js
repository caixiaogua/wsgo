function onOpen(ctx){
	console.log("open", ctx.Id, "conns", ctx.GetAllConns().length)
}

function onMsg(ctx, msg){
	console.log("msg", msg)
	var conns=ctx.GetAllConns()
//	console.log("conns", conns.length, JSON.stringify(conns))
//	conns=conns.filter(function(x){return x.Id!=ctx.Id}) //其他人
	ctx.SendTo(conns, "Reply:"+msg)
}

function onClose(ctx, err){
	console.log("close")
}