
let count=0;
let users=[];

function onOpen(ctx){
	count++;
	if(!users.find(x=>x.Id==ctx.Id))users.push(ctx);
	console.log("open", ctx.Id, count, users.length);
}

function onMsg(ctx, msg){
	console.log("msg", msg);
	api.sendTo(users, msg);
}

function onClose(ctx, err){
	console.log("close",ctx.Id);
}